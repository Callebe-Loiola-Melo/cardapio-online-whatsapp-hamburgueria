document.addEventListener('DOMContentLoaded', () => {
    

    const carrinhoItens = {}; 

    const btnCarrinho = document.getElementById('btn-carrinho');
    const cartCountSpan = document.getElementById('cart-count');
    const carrinhoAside = document.getElementById('carrinho');
    const finalizarBtn = document.getElementById('finalizar-btn');
    const incrementBtns = document.querySelectorAll('.increment');
    const decrementBtns = document.querySelectorAll('.decrement');
    const localEntregaRadios = document.querySelectorAll('input[name="local"]');

    btnCarrinho.addEventListener('click', () => {
        carrinhoAside.classList.toggle('active'); 
    });

   
    function adicionarAoCarrinho(nome, preco) {
        if (carrinhoItens[nome]) {
            carrinhoItens[nome].quantidade++;
        } else {
            carrinhoItens[nome] = { preco, quantidade: 1 };
        }
        atualizarCarrinhoHTML();
    }

    function removerDoCarrinho(nome) {
        if (carrinhoItens[nome]) {
            carrinhoItens[nome].quantidade--;
            if (carrinhoItens[nome].quantidade <= 0) {
                delete carrinhoItens[nome];
            }
        }
        atualizarCarrinhoHTML();
    }
    
    function atualizarCarrinhoHTML() {
        const itensCarrinhoDiv = document.getElementById('itens-carrinho');
        const valorTotalSpan = document.getElementById('valor-total');
        let subtotalItens = 0;
        let quantidadeTotalNoCarrinho = 0;
        itensCarrinhoDiv.innerHTML = ''; 

        for (const nome in carrinhoItens) {
            const item = carrinhoItens[nome];
            const itemDiv = document.createElement('div');
            itemDiv.innerHTML = `<span>${item.quantidade}x ${nome}</span>`;
            itensCarrinhoDiv.appendChild(itemDiv);
            subtotalItens += item.preco * item.quantidade;
            quantidadeTotalNoCarrinho += item.quantidade;
        }

        cartCountSpan.textContent = quantidadeTotalNoCarrinho;

        const localEntregaSelecionado = document.querySelector('input[name="local"]:checked');
        const taxaEntrega = localEntregaSelecionado ? parseFloat(localEntregaSelecionado.value) : 0;
        
        const totalComTaxa = subtotalItens + taxaEntrega;
        valorTotalSpan.textContent = totalComTaxa.toFixed(2).replace('.', ',');
    }

    incrementBtns.forEach(button => {
        button.addEventListener('click', (event) => {
            const itemDiv = event.target.closest('.item');
            const nome = itemDiv.dataset.name;
            const preco = parseFloat(itemDiv.dataset.price);
            const quantidadeSpan = itemDiv.querySelector('.quantidade');
            
            let quantidadeAtual = parseInt(quantidadeSpan.textContent);
            quantidadeAtual++;
            quantidadeSpan.textContent = quantidadeAtual;
            
            adicionarAoCarrinho(nome, preco);
        });
    });

    decrementBtns.forEach(button => {
        button.addEventListener('click', (event) => {
            const itemDiv = event.target.closest('.item');
            const nome = itemDiv.dataset.name;
            const quantidadeSpan = itemDiv.querySelector('.quantidade');
            
            let quantidadeAtual = parseInt(quantidadeSpan.textContent);
            if (quantidadeAtual > 0) {
                quantidadeAtual--;
                quantidadeSpan.textContent = quantidadeAtual;
                removerDoCarrinho(nome);
            }
        });
    });
    
    
    if (finalizarBtn) {
        finalizarBtn.addEventListener('click', (event) => {
            event.preventDefault(); 
            
            const observacao = document.getElementById('observacao').value.trim();
            const endereco = document.getElementById('endereco').value.trim();
            const localEntregaEl = document.querySelector('input[name="local"]:checked');
            const pagamentoEl = document.querySelector('input[name="pagamento"]:checked');
            
          

            if (Object.keys(carrinhoItens).length === 0) {
                alert('Seu carrinho está vazio. Adicione itens antes de finalizar o pedido.');
                return;
            }
            
            if (!localEntregaEl || !endereco || !pagamentoEl) {
                alert('Por favor, preencha o endereço, local de entrega e forma de pagamento.');
                return;
            }

            let mensagem = "Olá! Gostaria de fazer um pedido:\n\n";
            mensagem += "🍽️ *MEU PEDIDO:*\n";
            let subtotal = 0;

            for (const nome in carrinhoItens) {
                const item = carrinhoItens[nome];
                subtotal += item.preco * item.quantidade;
                mensagem += `- ${item.quantidade}x ${nome}\n`;
            }

            const taxa = parseFloat(localEntregaEl.value);
            const total = subtotal + taxa;
            
            mensagem += "\n"; 
            if (observacao) {
                mensagem += `📝 *Observações:*\n${observacao}\n\n`;
            }
            mensagem += "📍 *DADOS DE ENTREGA:*\n";
            mensagem += `*Endereço:* ${endereco}\n`;
            const localNome = localEntregaEl.parentElement.textContent.trim();
            mensagem += `*Local:* ${localNome}\n\n`;


            mensagem += "💰 *PAGAMENTO:*\n";
            mensagem += `*Forma de Pagamento:* ${pagamentoEl.value.toUpperCase()}\n`;
            mensagem += `*Total (com entrega):* R$ ${total.toFixed(2).replace('.', ',')}\n\n`;

            const numeroWhatsApp = "ColoqueseuNUMEROaqui"; 
            const mensagemCodificada = encodeURIComponent(mensagem);
            
            window.open(`https://api.whatsapp.com/send?phone=${numeroWhatsApp}&text=${mensagemCodificada}`, '_blank');
        });
    }

    localEntregaRadios.forEach(radio => {
        radio.addEventListener('change', atualizarCarrinhoHTML); 
    });

    
    atualizarCarrinhoHTML(); 
});